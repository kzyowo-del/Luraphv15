# Luraph V15 Deobfuscator — Web App

## Deploy lên Railway (Free, dễ nhất)

1. Tạo tài khoản tại https://railway.app (dùng GitHub login)
2. Nhấn **New Project → Deploy from GitHub repo**
3. Upload folder này lên GitHub (hoặc dùng Railway CLI)
4. Railway tự detect Node.js và deploy
5. Lấy URL từ dashboard, dùng trên mobile!

## Deploy lên Render (Free tier)

1. Tạo tài khoản tại https://render.com
2. **New → Web Service → Connect GitHub**
3. Settings:
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Environment: `Node`
4. Deploy!

## Chạy local (Termux / PC)

```bash
npm install
node server.js
# Mở http://localhost:3000
```

## Yêu cầu

- Node.js 18+
- Python 3.10+ (engine deobf cần Python)
- RAM tối thiểu 512MB (khuyến nghị 1GB+)

## API Endpoints

- `POST /api/detect` — Detect obfuscator type
- `POST /api/deobfuscate` — Deobfuscate script
  - body: `{ source: string, mode: "full" | "trace" }`
